package com.example.smedicine.bean;

public class Plan {
    String medlicense;
    int medbox;
    String times;
    String medicinetime;
    String num;

    public String getMedlicense() {
        return medlicense;
    }

    public void setMedlicense(String medlicense) {
        this.medlicense = medlicense;
    }

    public int getMedbox() {
        return medbox;
    }

    public void setMedbox(int medbox) {
        this.medbox = medbox;
    }

    public String getTimes() {
        return times;
    }

    public void setTimes(String times) {
        this.times = times;
    }

    public String getMedicinetime() {
        return medicinetime;
    }

    public void setMedicinetime(String medicinetime) {
        this.medicinetime = medicinetime;
    }

    public String getNum() {
        return num;
    }

    public void setNum(String num) {
        this.num = num;
    }
}
